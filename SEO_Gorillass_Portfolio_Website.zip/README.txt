SEO Gorillass — Free Portfolio Website

1. Upload index.html to a GitHub repository.
2. Settings → Pages → Deploy from branch → main → /root.
3. GitHub Pages provides a free public URL.

Before publishing, review team contact information and any campaign/backlink URLs you want to keep private.
